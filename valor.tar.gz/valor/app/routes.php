<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/



Route::get('/', function()
{
    return View::make('index');
});

Route::group(array('prefix' => 'admin'), function(){

    Route::post('login', array('as' => 'admin.login', 'uses' => 'RequestController@getLogin'));
    Route::get('all-members', array('as' => 'admin.all-members', 'uses' => 'RequestController@getMembers'));
    Route::post('remove-member/{id}', array('as' => 'admin.remove-member', 'uses' => 'RequestController@postRemoveMember'));
    Route::get('join-requests', array('as' => 'admin.join-requests', 'uses' => 'RequestController@getJoinRequests'));
    Route::post('join-requests/{id}/option', array('as' => 'admin.join-requests', 'uses' => 'RequestController@postAddRejectMember'));
    Route::get('community-settings', array('as' => 'admin.community-settings', 'uses' => 'RequestController@getSettings'));
    Route::put('community-settings/{id}', array('as' => 'admin.community-settings', 'uses' => 'RequestController@putSettings'));
});

