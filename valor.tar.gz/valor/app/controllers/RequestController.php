<?php

use GuzzleHttp;

class RequestController extends BaseController {

	/*
	|--------------------------------------------------------------------------
	| Default Home Controller
	|--------------------------------------------------------------------------
	|
	| You may wish to use controllers instead of, or in addition to, Closure
	| based routes. That's great! Here is an example controller method to
	| get you started. To route to this controller, just add the route:
	|
	|	Route::get('/', 'HomeController@showWelcome');
	|
	*/


	public function getLogin()
	{
		
		$client = new \GuzzleHttp\Client();
		$options['headers'] = ['Content-Type' => 'application/json'];
		$url = Config::get('valor.url').'login';
		// $url = Config::get('valor.url').'login';
	    $res = $client->post($url, [
	        'auth' =>  ['firstadmin@school.edu', '123456']
	    ]);
	    return $res->getBody();
	    // var_dump($res);
	    // return $res->getHeader('content-type');
	    //return $res;

	    //return Redirect::route('admin.login');
	}

	// public function getLogin()
	// {
	// 	$client = new GuzzleHttp\Client();
	//     $res = $client->get('http://localhost:8000/admin/login', [
	//         'auth' =>  ['firstadmin@school.edu', '123456'],
	//         'body' => ['all_swipes' => Input::get('all_swipes'),
	//                     'right_swipes' => Input::get('right_swipes'),
	//                     'matches' => Input::get('matches'),
	//                     'conversations' => Input::get('conversations')]
	//     ]);

	//     return Redirect::route('login.show');
	// }

	public function getMembers()
	{
		$client = new GuzzleHttp\Client();
		$url = Config::get('valor.url').'all-members';
	    $res = $client->get($url, [
	        'auth' =>  ['firstadmin@school.edu', '123456']
	    ]);

	    //return $res;
	    return $res->getBody();
	}

	// public function getMembers()
	// {
	// 	$client = new GuzzleHttp\Client();
	//     $res = $client->get('http://localhost:8000/admin/all-members', [
	//         'auth' =>  ['firstadmin@school.edu', '123456'],
	//         'body' => ['id' => Input::get('id'),
	//                     'picture_url' => Input::get('picture_url'),
	//                     'join_date' => Input::get('join_date'),
	//                     'first_name' => Input::get('first_name'),
	//                     'last_name' => Input::get('last_name'),
	//                     'title' => Input::get('title'),
	//                     'company' => Input::get('conversations'),
	//                     'email_address' => Input::get('email_address'),
	//                     'linked_in_url' => Input::get('linked_in_url'),
	//                     'class_year' => Input::get('class_year')]
	//     ]);

	//     return Redirect::route('admin.all-members');
	// }

	public function postRemoveMember($id)
	{
		$client = new GuzzleHttp\Client();
		$options['headers'] = ['Content-Type' => 'application/x-www-form-urlencoded'];
		$url = Config::get('valor.url').'remove-member/'.$id;
	    $res = $client->post($url, [
	        'auth' =>  ['firstadmin@school.edu', '123456'],

	        // 'json' => ['id' => Input::get('id')]
	        'body' => json_encode(['id' => Input::get('id')])
	    ]);

	    // return $res;
	    // return $res->getHeader('content-type');
	    return $res->getBody();
	}

	// public function postRemoveMember($id)
	// {
	// 	$options['headers'] = ['Content-Type' => 'application/json'];
	// 	$client = new GuzzleHttp\Client();
	//     $res = $client->post('http://localhost:8000/admin/remove-member', [
	//         'auth' =>  ['firstadmin@school.edu', '123456'],
	//         'body' => ['json' => ['id' => Input::get('id')]]
	//                     // 'reason' => Input::get('reason')]
	//     ])->send();

	//     return $res;
	// }

	public function getJoinRequests()
	{
		$client = new GuzzleHttp\Client();
		$url = Config::get('valor.url').'join-requests';
	    $res = $client->get($url, [
	        'auth' =>  ['firstadmin@school.edu', '123456']
	    ]);

	    // return $res;
	    return $res->getBody();
	}

	// public function getJoinRequests()
	// {
	// 	$client = new GuzzleHttp\Client();
	//     $res = $client->get('http://localhost:8000/admin/join-requests', [
	//         'auth' =>  ['firstadmin@school.edu', '123456'],
	//         'body' => ['id' => Input::get('id'),
	//                     'picture_url' => Input::get('picture_url'),
	//                     'join_date' => Input::get('join_date'),
	//                     'first_name' => Input::get('first_name'),
	//                     'last_name' => Input::get('last_name'),
	//                     'title' => Input::get('title'),
	//                     'company' => Input::get('conversations'),
	//                     'email_address' => Input::get('email_address'),
	//                     'linked_in_url' => Input::get('linked_in_url'),
	//                     'class_year' => Input::get('class_year')]
	//     ]);

	//     return Redirect::route('admin.join-requests');
	// }


	public function postAddRejectMember($id)
	{

	    $client = new GuzzleHttp\Client();
	    //$id = Input::get('id');
		$option = Input::get('option');
	    
	    $url = Config::get('valor.url').'join-requests/'.$id.'/option?option='.$option;
	    $res = $client->post( $url , [
	        'auth' =>  ['firstadmin@school.edu', '123456'],
	        'body' => json_encode(['id' => $id,
	        	'option' => $option])
	        //option could be accept or reject
	    ]);

	    // return $res;
	    return $res->getBody();
	}

	public function getSettings()
	{
		$client = new GuzzleHttp\Client();
		$url = Config::get('valor.url').'community-settings';
	    $res = $client->get( $url, [
	        'auth' =>  ['firstadmin@school.edu', '123456']
	    ]);

	    // return $res;
	    return $res->getBody();
	}

	// public function putSettings($id)
	// {
	//     $client = new GuzzleHttp\Client();
	//     $res = $client->put('http://localhost:8000/admin/community-settings', [
	//         'auth' =>  ['firstadmin@school.edu', '123456'],
	//         'headers' => ['Content-Type' => 'application/json', 'Accept' => 'application/json'],
	//         'body' => ["color3" => "#3CD88"]
	//     ]);

	//     // return $res;
	//     return $res->getBody();
	// }

// 	$response = GuzzleHttp\post('http://www.example.com:1234/rest/user/validat', [
//         'headers' => ['Content-Type' => 'application/json', 'Accept' => 'application/json'],
//         'body'    => '{"email":"user@domain.com", "pwd":"xxxxxx"}'
// ]);     
// print_r($response->json());

	public function putSettings($id)
	{
	    $client = new GuzzleHttp\Client();
	    $url = Config::get('valor.url').'community-settings/'.$id. '?';
	    $color1 = Input::get('color1');
	    $color2 = Input::get('color2');
	    $color3 = Input::get('color3');
	    $welcome_logo = Input::get('welcome_logo');
	    $app_header = Input::get('app_header');
	    $menu_header = Input::get('menu_header');

	       if ( Request::get('color1') )
		    {
		        $params['color1'] = Request::get('color1');
		    }
		 
		    if ( Request::get('color2') )
		    {
		        $params['color2'] = Request::get('color2');
		    }

		    if ( Request::get('color3') )
		    {
		        $params['color3'] = Request::get('color3');
		    }

		    if ( Request::get('welcome_logo') )
		    {
		        $params['welcome_logo'] = Request::get('welcome_logo');
		    }

		    if ( Request::get('app_header') )
		    {
		        $params['app_header'] = Request::get('app_header');
		    }

		    if ( Request::get('menu_header') )
		    {
		        $params['menu_header'] = Request::get('menu_header');
		    }

	    
	    
	    
	    $res = $client->put($url . http_build_query($params) , [
	        'auth' =>  ['firstadmin@school.edu', '123456'],
	        // 'body' => json_encode([
	        // 			'color1' => $color1,
	        //             'color2' => $color2,
	        //             'color3' => $color3,
	        //             'welcome_logo' => $welcome_logo,
	        //             'app_header' => $app_header,
	        //             'menu_header' => $menu_header
	        //             ])
	    ]);

	    // return $res;
	    return $res->getBody();
	}
}
