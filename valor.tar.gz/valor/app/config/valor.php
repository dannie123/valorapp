<?php

return array(

	'url' => 'http://104.131.244.106/valorserver/public/index.php/admin/'

);
